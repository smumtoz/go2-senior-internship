"""Export real TensorBoard scalars and compare the three Go2 experiments.

Usage: python analyze_runs.py ISAACLAB_LOG_ROOT OUTPUT_DIRECTORY
Requires tensorboard, numpy, and matplotlib in the Isaac Lab environment.
"""

import csv
import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from tensorboard.backend.event_processing.event_accumulator import EventAccumulator


def analyze(log_root, output):
    log_root, output = Path(log_root), Path(output)
    output.mkdir(parents=True, exist_ok=True)
    labels = ("baseline", "wide", "wide_long")
    metrics = ("error_vel_xy", "success_rate", "base_contact")
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5))
    rows, summaries = [], []
    for label in labels:
        candidates = sorted(p for p in log_root.iterdir() if p.is_dir() and p.name.endswith("_" + label))
        if len(candidates) != 1:
            raise ValueError(f"Expected exactly one {label} run; found {len(candidates)}")
        run = candidates[0]
        accumulator = EventAccumulator(str(run), size_guidance={"scalars": 0})
        accumulator.Reload()
        tags = accumulator.Tags()["scalars"]
        summary = {"run": label, "directory": run.name, "window": "last 30 logged scalar observations"}
        for metric, ax in zip(metrics, axes):
            matches = [tag for tag in tags if tag.split("/")[-1] == metric]
            if len(matches) != 1:
                raise ValueError(f"Ambiguous or missing {metric} in {run}: {matches}; tags={tags}")
            tag = matches[0]
            events = accumulator.Scalars(tag)
            if not events:
                raise ValueError(f"No scalar observations for {tag} in {run}")
            steps = np.array([e.step for e in events])
            values = np.array([e.value for e in events])
            if not np.isfinite(values).all():
                raise ValueError(f"Non-finite values for {tag} in {run}")
            tail = values[-30:]
            summary[metric] = {
                "tag": tag,
                "last_value": float(values[-1]),
                "last_step": int(steps[-1]),
                "tail_mean": float(tail.mean()),
                "tail_std": float(tail.std()),
                "observations": len(events),
            }
            for event in events:
                rows.append([label, tag, event.step, event.wall_time, event.value])
            raw_line, = ax.plot(steps, values, alpha=0.18)
            width = min(15, len(values))
            smooth = np.convolve(values, np.ones(width) / width, mode="valid")
            ax.plot(steps[width - 1 :], smooth, label=label, color=raw_line.get_color())
        summaries.append(summary)
    for ax, title, unit in zip(
        axes,
        ("Planar velocity tracking error", "Command tracking success", "Base-contact termination indicator"),
        ("m/s", "Logged fraction", "Logged fraction"),
    ):
        ax.set(title=title, xlabel="Training iteration", ylabel=unit)
        ax.grid(alpha=0.2)
        ax.legend()
    fig.suptitle("Go2 flat terrain: default vs wider commands (15-observation moving average)")
    fig.tight_layout()
    fig.savefig(output / "training_comparison.png", dpi=180)
    plt.close(fig)
    with (output / "scalars.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["run", "tag", "iteration", "wall_time", "value"])
        writer.writerows(rows)
    (output / "metrics_summary.json").write_text(json.dumps(summaries, indent=2), encoding="utf-8")
    print(json.dumps(summaries, indent=2))


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Usage: python analyze_runs.py ISAACLAB_LOG_ROOT OUTPUT_DIRECTORY")
    analyze(*sys.argv[1:])
