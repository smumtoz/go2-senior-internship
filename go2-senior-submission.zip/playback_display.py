"""Lower the Newton viewer resolution for playback on Colab's software OpenGL.

Use --external_callback playback_display.configure with this directory on PYTHONPATH.
This changes display settings only. Training configurations and checkpoints are untouched.
"""

import gymnasium as gym

import isaaclab_tasks  # noqa: F401
from isaaclab.visualizers.visualizer_cfg import WindowCfg
from isaaclab_tasks.core.velocity.config.go2.flat_env_cfg import UnitreeGo2FlatEnvCfg
from isaaclab_visualizers.newton import NewtonGLVisualizerCfg


def make_playback_config():
    cfg = UnitreeGo2FlatEnvCfg()
    cfg.sim.default_visualizer_cfg = NewtonGLVisualizerCfg(
        window=WindowCfg(size=(640, 360)), enable_shadows=False
    )
    return cfg


def configure():
    gym.spec("Isaac-Velocity-Flat-UnitreeGo2").kwargs["env_cfg_entry_point"] = make_playback_config
